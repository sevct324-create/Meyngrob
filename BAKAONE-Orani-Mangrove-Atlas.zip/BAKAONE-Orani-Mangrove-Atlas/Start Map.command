#!/bin/zsh
cd "$(dirname "$0")"
PORT=8097
ruby -run -e httpd . -p "$PORT" &
SERVER_PID=$!
trap 'kill "$SERVER_PID" 2>/dev/null' EXIT INT TERM
sleep 1
open "http://127.0.0.1:$PORT/"
wait "$SERVER_PID"
