// Brand and home page integration settings. Replace homeUrl when the main site is ready.
export const siteConfig = {
  brand: 'BAKAONE',
  homeUrl: '#',
  colors: { forest: '#123528', leaf: '#4f8060', sky: '#9bc0df', paper: '#f4f5ef' },
  mapCenter: [14.80, 120.54],
  mapZoom: 12,
  imagery: 'esri-world-imagery',
};
