import { siteConfig } from './config.js';
import { inventory, mangroveStations, reportedOraniStationsAreaKm2, oraniBoundary, mangroveFeatures } from '../data/mangroves.js';

const map = L.map('map', { zoomControl: false, scrollWheelZoom: true }).setView(siteConfig.mapCenter, siteConfig.mapZoom);
const imagery = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
  maxZoom: 19, attribution: 'Tiles © Esri — Sources: Esri, Maxar, Earthstar Geographics, and the GIS User Community'
});
const fallback = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19, attribution: '© OpenStreetMap contributors'
});
let failedTiles = 0;
imagery.on('tileerror', () => { failedTiles += 1; if (failedTiles >= 3 && !map.hasLayer(fallback)) { map.addLayer(fallback); showMessage('Satellite imagery is unavailable. Showing the street map instead.', true); } });
imagery.on('load', () => { if (failedTiles < 3) showMessage('', false); });
imagery.addTo(map);

const boundaryStyle = { color: '#a9cce7', weight: 2.5, opacity: 0.95, fillColor: '#9bc0df', fillOpacity: 0.08, dashArray: '7 5' };
const mangroveStyle = { color: '#b7e28b', weight: 2, fillColor: '#75bc58', fillOpacity: 0.52 };
const boundaryLayer = L.geoJSON(oraniBoundary || null, { style: boundaryStyle });
const mangroveLayer = mangroveFeatures ? L.geoJSON(mangroveFeatures, {
  style: mangroveStyle,
  onEachFeature: (feature, layer) => {
    const p = feature.properties || {};
    layer.bindPopup(`<strong>${escapeHtml(p.name || 'Mangrove area')}</strong><br/>${escapeHtml(p.areaLabel || 'Area information unavailable')}`);
  }
}) : L.layerGroup();
const barangayCenterLayer = L.layerGroup(inventory.barangays.filter(item => item.center).map(item => {
  const [lat, lng] = item.center;
  return L.circleMarker([lat, lng], {
    radius: 7, color: '#173d32', weight: 2, fillColor: '#9bc0df', fillOpacity: 1,
    title: `${item.name} approximate barangay center`
  })
    .bindTooltip(escapeHtml(item.name))
    .bindPopup(`<strong>${escapeHtml(item.name)}</strong><br/>Approximate barangay center<br/>${lat.toFixed(4)}° N, ${lng.toFixed(4)}° E<br/><small>Not a mangrove location or barangay boundary.</small>`);
}));
const mangroveStationLayer = L.layerGroup(mangroveStations.map(station => L.circleMarker(
  [station.latitude, station.longitude],
  { radius: 8, color: '#173d32', weight: 2, fillColor: '#75bc58', fillOpacity: 1, title: `${station.name} mangrove inventory station` }
)
  .bindTooltip(escapeHtml(station.name))
  .bindPopup(`<strong>${escapeHtml(station.name)}</strong><br/>Reported area: ${station.areaKm2} km²<br/>${escapeHtml(station.setting)} · ${escapeHtml(station.species)}<br/><small>Reported inventory station coordinate; no site boundary geometry provided.</small>`)));
boundaryLayer.addTo(map);
barangayCenterLayer.addTo(map);
mangroveStationLayer.addTo(map);
if (mangroveFeatures) mangroveLayer.addTo(map);

// Bundle a PSGC-aligned municipal outline locally so it remains available without a live GIS API.
if (!oraniBoundary) {
  fetch('./data/orani-boundary.geojson')
    .then(response => {
      if (!response.ok) throw new Error('Boundary file unavailable');
      return response.json();
    })
    .then(data => {
      boundaryLayer.addData(data);
      const bounds = boundaryLayer.getBounds();
      if (bounds.isValid()) map.fitBounds(bounds.pad(0.12), { maxZoom: siteConfig.mapZoom });
      document.querySelector('.legend small').textContent = 'Municipal outline: PSGC-aligned source; verify with the LGU for official use.';
      showMessage('', false);
    })
    .catch(() => {
      document.querySelector('.legend small').textContent = 'Municipal boundary file could not load. Check the setup notes.';
    });
}

// Simple, independent toggles: satellite imagery and verified mangrove features.
const overlayLayers = {
  'Orani boundary': boundaryLayer,
  'Approx. barangay centers': barangayCenterLayer,
  'Mangrove inventory stations (points)': mangroveStationLayer
};
if (mangroveFeatures) overlayLayers['Verified mangrove polygons'] = mangroveLayer;
L.control.layers({ 'Satellite imagery': imagery, 'Street map': fallback }, overlayLayers, { collapsed: true }).addTo(map);

for (const [id, fn] of [['zoom-in', () => map.zoomIn()], ['zoom-out', () => map.zoomOut()], ['reset-view', () => map.setView(siteConfig.mapCenter, siteConfig.mapZoom)]]) document.getElementById(id).addEventListener('click', fn);

function showMessage(message, visible = true) {
  const el = document.getElementById('map-message');
  el.classList.toggle('hidden', !visible || !message);
  el.innerHTML = message ? `<span>${escapeHtml(message)}</span>` : '';
}
function escapeHtml(value) { return String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]); }

const list = document.getElementById('barangay-list');
for (const item of mangroveStations) {
  const li = document.createElement('li');
  li.innerHTML = `<span>${escapeHtml(item.name)}</span><b>${item.areaKm2} km²</b>`;
  list.append(li);
}
document.getElementById('total-area').textContent = `${reportedOraniStationsAreaKm2.toFixed(4)} km²`;
for (const id of ['home-link', 'nav-home-link']) document.getElementById(id).href = siteConfig.homeUrl;

map.whenReady(() => { setTimeout(() => { if (document.getElementById('map-message').classList.contains('hidden')) return; showMessage('Loading satellite imagery…'); }, 1200); });
setTimeout(() => { if (document.getElementById('map-message').textContent.includes('Loading')) showMessage('Imagery may be slow or blocked. Try the layer menu or refresh when connected.', true); }, 10000);

const menuButton = document.querySelector('.menu-button');
menuButton.addEventListener('click', () => {
  const nav = document.querySelector('.topbar nav');
  const expanded = menuButton.getAttribute('aria-expanded') === 'true';
  menuButton.setAttribute('aria-expanded', String(!expanded));
  nav.classList.toggle('open', !expanded);
});
