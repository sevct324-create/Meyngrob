# BAKAONE Orani Mangrove Atlas

A responsive, static Leaflet map page that can be connected to a future BAKAONE home page without assuming its framework or URL. The project started empty, so this implementation uses plain HTML, CSS, and JavaScript modules.

## Run

Serve this folder over HTTP (ES modules do not work reliably from `file://`), for example:

```sh
python3 -m http.server 8000
```

Then open `http://localhost:8000`.

## Configure the future home page and brand

Edit `src/config.js`:

- `homeUrl`: set the future site's URL or route. The brand links in the header and footer use this value.
- `colors`: central brand palette; the matching CSS custom properties are at the top of `styles.css`.
- `mapCenter` and `mapZoom`: initial map position.

The navigation is intentionally plain HTML and can be replaced with the future site's own links or router later.

## Imagery and attribution

The map uses Leaflet 1.9.4 from unpkg and Esri World Imagery tiles. No API key is required for this public basemap endpoint. Tile attribution is shown on the map: “Tiles © Esri — Sources: Esri, Maxar, Earthstar Geographics, and the GIS User Community.” A street-map fallback is available in the layer menu and is also added if satellite tiles repeatedly fail; it carries OpenStreetMap attribution. Check the provider's current terms before a high-traffic or commercial deployment. If you switch to MapTiler, Mapbox, or another key-based provider, keep the key in deployment configuration and document any domain restrictions; do not commit a private key.

The Orani outline currently bundled in `data/orani-boundary.geojson` is from the PSGC-aligned Philippine administrative boundary dataset by James Faeldon, built from NAMRIA/PSA source boundaries through OCHA's COD-AB. The source boundary data is CC BY-IGO; the map shows source credit. It is a reference outline and should be confirmed with the municipal LGU for official or survey use. The map fetches this local file, so it remains available without a live GIS service.

## GIS data expected

Keep source data in `data/mangroves.js`, separate from display code in `src/app.js`.

- `oraniBoundary`: optional GeoJSON Feature or FeatureCollection for a verified replacement municipal boundary. If null, the bundled `data/orani-boundary.geojson` reference boundary is loaded.
- `mangroveFeatures`: a GeoJSON FeatureCollection of verified mangrove areas. Include `properties.name` and, where available, `properties.areaLabel`. The current UI must not imply that barangay totals are geographic features.
- `mangroveStations`: report station records with latitude/longitude and area (km²), displayed as points with popups. The area values do not define polygon boundaries.
- The `center` arrays on barangay inventory entries are approximate latitude/longitude barangay center points supplied by the user, with PhilAtlas as the cited reference. They render as a separate “Approx. barangay centers” layer. They do not represent mangrove sites or barangay boundaries.
- GeoJSON should use WGS 84 longitude/latitude coordinates (EPSG:4326 / RFC 7946). If using a shapefile, convert the full set of `.shp`, `.shx`, `.dbf`, and `.prj` files to GeoJSON before loading. Do not digitize guessed polygons from the summary table.
- The screenshot attachment is the BAKAONE homepage visual reference; its mentioned barangay table was not present. Separately, the linked PEMSEA 2024 report provides Table 37 survey station values for Kabalutan 1–3, Kaparangan, and Tubo-tubo Island. Values are stored as printed in km² in `mangroveStations`; the named screenshot barangay summary remains blank where that report has no matching row.

The municipal outline is displayed from the bundled PSGC-aligned reference file. Replace it with the municipal authority's preferred boundary when available. Approximate barangay center markers currently cover Tapulao, Kabalutan, Pantalan Luma, Pantalan Bago, and Kaparangan, sourced from [PhilAtlas Orani](https://www.philatlas.com/luzon/r03/bataan/orani/). Green mangrove inventory markers use Table 37 of the [Second State of the Coasts of Bataan Province](https://pemsea.org/sites/default/files/2024-07/Second%20Bataan%20SOC%202024.pdf), published by PEMSEA in 2024; the table's underlying Rapid Resource Inventory is dated December 2020. The displayed 0.4373 km² is the calculated sum of the five Orani-associated rows shown, not a reported or comprehensive municipal total. The report's 0.65 km² figure is for all Northeast Bataan. The report provides station coordinates and area values, but not site boundary polygons; the map shows the stations as points.

## Start on a Mac without Python

Double-click `Start Map.command`. If macOS blocks it, right-click the file, choose **Open**, then confirm. It starts a local Ruby web server and opens the map at `http://127.0.0.1:8097`. Keep the Terminal window open while using the map; press Control+C there to stop the server.

## Publish with GitHub Pages

1. Create a GitHub repository and upload the contents of this folder to the repository root. Keep `src/` and `data/` as folders next to `index.html`.
2. In the repository, open **Settings → Pages**.
3. Under **Build and deployment**, select **Deploy from a branch**, choose your publishing branch (usually `main`) and folder **/(root)**, then save.
4. After GitHub Pages finishes deploying, open the URL shown in the Pages settings.

This is a static site: it has no build step and needs no map API key. Browsers need an internet connection to load Leaflet, fonts, satellite imagery, and map tiles. `.nojekyll` is included for static hosting.
