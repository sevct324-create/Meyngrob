// Barangay summaries and approximate centers are reference data, not mangrove locations.
export const inventory = {
  total: { value: null, unit: null, columnMeaning: null },
  barangays: [
    { name: 'Tapulao', area: null, unit: null, center: [14.8131, 120.5208] },
    { name: 'Kabalutan', area: null, unit: null, center: [14.8166, 120.5369] },
    { name: 'Pantalan Luma', area: null, unit: null, center: [14.8013, 120.5417] },
    { name: 'Pantalan Bago', area: null, unit: null, center: [14.8033, 120.5412] },
    { name: 'Kaparangan', area: null, unit: null, center: [14.7926, 120.5396] },
  ],
};

export const barangayCenterSource = 'https://www.philatlas.com/luzon/r03/bataan/orani/';

// Table 37, Second State of the Coasts of Bataan Province (PEMSEA, 2024).
// These are report station coordinates and area values, not polygon boundaries.
export const mangroveStations = [
  { name: 'Tubo-tubo Island', latitude: 14.8134, longitude: 120.5576, areaKm2: 0.0789, setting: 'Coastal', species: 'S. alba' },
  { name: 'Kabalutan 1', latitude: 14.8127, longitude: 120.5515, areaKm2: 0.1013, setting: 'Riverine', species: 'R. mucronata' },
  { name: 'Kabalutan 2', latitude: 14.8146, longitude: 120.5461, areaKm2: 0.0775, setting: 'Riverine', species: 'S. alba' },
  { name: 'Kabalutan 3', latitude: 14.8091, longitude: 120.5424, areaKm2: 0.0827, setting: 'Riverine', species: 'S. caseolaris' },
  { name: 'Kaparangan', latitude: 14.7915, longitude: 120.5485, areaKm2: 0.0969, setting: 'Riverine', species: 'S. alba' },
];
export const mangroveInventorySource = 'https://pemsea.org/sites/default/files/2024-07/Second%20Bataan%20SOC%202024.pdf';

// Calculated sum of the five Orani station rows above; not a comprehensive Orani total.
export const reportedOraniStationsAreaKm2 = 0.4373;

// Add only accurate WGS84 GeoJSON here when supplied; empty until GIS source is provided.
export const oraniBoundary = null;
export const mangroveFeatures = null;
